MyFruitList = ["apple", "banana", "Cherry"]
print(MyFruitList)
print(type(MyFruitList))

print(MyFruitList[0])
print(MyFruitList[1])
print(MyFruitList[2])

MyFruitList[2] = "Orange"
print(MyFruitList)

myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))

print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])

myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}

print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))

print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])

